To {username},

Thank you for creating an account with {site_name}. {activation_message}

Your Login Details:
Email: {email}
Password: {password}

If you did not register with us, then please ignore this email.

Many thanks from the {site_name} team.

{site_url}