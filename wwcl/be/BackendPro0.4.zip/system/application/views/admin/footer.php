    <div id="footer">
        <div id="copyright">
            <a href="http://www.kaydoo.co.uk/projects/backendpro">BackendPro</a> &copy; Copyright 2008 - <a href="http://www.kaydoo.co.uk">Adam Price</a> -  All rights Reserved
        </div>
        <div id="version">
            <a href="#top"><?=$this->lang->line('general_top')?></a> | 
            <a href="../user_guide"><?=$this->lang->line('general_documentation')?></a> |  
            Version <?=BEP_VERSION?></div>
    </div>
</div>

</body>
</html>