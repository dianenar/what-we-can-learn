<h2><?=$header?></h2>
<p><?=$message?></p>
<p><?=$this->lang->line('backendpro_maintenance_login')?></p>
