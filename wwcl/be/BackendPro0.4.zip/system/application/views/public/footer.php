    <div id="footer">
        <a href="#top"><?=$this->lang->line('general_top')?></a><br />
        This site is powered by <a href="http://www.kaydoo.co.uk/projects/backendpro">BackendPro <?=BEP_VERSION?></a><br />
        &copy; Copyright 2008 - <a href="http://www.kaydoo.co.uk">Adam Price</a> -  All rights Reserved
    </div> 
</div>

</body>
</html>